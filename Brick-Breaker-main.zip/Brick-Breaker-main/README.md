# Brick-Breaker
The developed game is a Brick breaker game. Developed on OOP concepts using C++ language, and the CMU Graphics Library
